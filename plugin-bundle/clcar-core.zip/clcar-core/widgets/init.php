<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\ClCar_Core;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Custom_Widgets_Init {

	public $widgets;
	protected static $instance = null;

	public function __construct() {

		// Widgets -- filename=>classname /@dev
		$this->widgets =  array(
			'about'             => 'About_Widget',
			'featured-post'     => 'ClCar_Feature_Post',
		);

        if ( class_exists( 'Rtcl' ) ) {
            $this->widgets += array(
                'advanced-search'   => 'Advanced_Search',
            );
        }

		add_action( 'widgets_init', array( $this, 'custom_widgets' ) );
	}

	public static function instance() {
		if ( null == self::$instance ) {
			self::$instance = new self;
		}
		return self::$instance;
	}

	public function custom_widgets() {
		if ( !class_exists( 'RT_Widget_Fields' ) ) return;

		foreach ( $this->widgets as $filename => $classname ) {

			$template_name = '/widgets/' . $filename . '.php';

			if ( file_exists( get_stylesheet_directory() . $template_name ) ) {
				$file = get_stylesheet_directory() . $template_name;
			}
			elseif ( file_exists( get_template_directory() . $template_name ) ) {
				$file = get_template_directory() . $template_name;
			}
			else {
				$file  = dirname( __FILE__ ) . '/' . $filename . '.php';
			}

			require_once $file;

			$class = __NAMESPACE__ . '\\' . $classname;
			register_widget( $class );
		}
	}
}

Custom_Widgets_Init::instance();