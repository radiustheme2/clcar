<?php

namespace RtclPro\Services\Mcp\Abilities;

use Rtcl\Services\Mcp\Helpers\CapabilityHelper;
use RtclPro\Services\Mcp\Services\MapIconService;

defined( 'ABSPATH' ) || exit;

/**
 * Pro-only category map icon ability (rtcl/set-category-map-icon).
 *
 * Registered on the base `rtcl_mcp_abilities_registered` action, inside the
 * base `rtcl-taxonomies` ability category.
 */
class MapIconAbilities {

	public static function register() {
		wp_register_ability( 'rtcl/set-category-map-icon', [
			'label'       => __( 'Set Category Map Icon', 'classified-listing-pro' ),
			'description' => __( 'Set or update the map marker icon for a category (stored in _rtcl_map_icon meta). Requires RTCL Pro. Supports external URL, local server path, base64 data, or existing attachment ID. Icons should be small (32-64px recommended). This is different from the FontAwesome icon class.', 'classified-listing-pro' ),
			'category'    => 'rtcl-taxonomies',
			'input_schema' => [
				'type'       => 'object',
				'properties' => [
					'term_id' => [
						'type'        => 'integer',
						'description' => __( 'Category term ID. Required.', 'classified-listing-pro' ),
					],
					'map_icon' => [
						'oneOf' => [
							[ 'type' => 'string', 'description' => __( 'Map icon URL, local path, or base64 data.', 'classified-listing-pro' ) ],
							[ 'type' => 'integer', 'description' => __( 'Existing WordPress attachment ID.', 'classified-listing-pro' ) ],
						],
						'description' => __( 'Map marker icon source: URL (https://...), local path (/path/to/icon.png), base64 data (data:image/...), or attachment ID.', 'classified-listing-pro' ),
					],
				],
				'required' => [ 'term_id', 'map_icon' ],
			],
			'output_schema' => [
				'type' => 'object',
				'properties' => [
					'term_id'           => [ 'type' => 'integer', 'description' => __( 'Category term ID.', 'classified-listing-pro' ) ],
					'taxonomy'          => [ 'type' => 'string', 'description' => __( 'Taxonomy slug.', 'classified-listing-pro' ) ],
					'name'              => [ 'type' => 'string', 'description' => __( 'Category name.', 'classified-listing-pro' ) ],
					'attachment_id'     => [ 'type' => 'integer', 'description' => __( 'New attachment ID.', 'classified-listing-pro' ) ],
					'url'               => [ 'type' => 'string', 'description' => __( 'New map icon URL.', 'classified-listing-pro' ) ],
					'dimensions'        => [
						'type'       => 'object',
						'properties' => [
							'width'  => [ 'type' => 'integer' ],
							'height' => [ 'type' => 'integer' ],
						],
					],
					'old_attachment_id' => [ 'type' => 'integer', 'description' => __( 'Previous attachment ID (if any).', 'classified-listing-pro' ) ],
					'old_url'           => [ 'type' => 'string', 'description' => __( 'Previous map icon URL (if any).', 'classified-listing-pro' ) ],
					'message'           => [ 'type' => 'string' ],
				],
			],
			'execute_callback' => function ( $input ) {
				$term_id = absint( $input['term_id'] ?? 0 );
				$map_icon = $input['map_icon'] ?? '';

				if ( ! $term_id ) {
					return new \WP_Error( 'missing_term_id', __( 'Category term ID is required.', 'classified-listing-pro' ) );
				}
				if ( empty( $map_icon ) ) {
					return new \WP_Error( 'missing_map_icon', __( 'Map icon is required.', 'classified-listing-pro' ) );
				}

				$service = new MapIconService();
				return $service->setMapIcon( rtcl()->category, $term_id, $map_icon );
			},
			'permission_callback' => CapabilityHelper::getManageOptionsCallback(),
			'meta' => [
				'public' => true,
				'mcp'    => [ 'public' => true ],
				'annotations' => [ 'readonly' => false, 'destructive' => false, 'idempotent' => true ],
			],
		] );
	}
}
