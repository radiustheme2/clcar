<?php

namespace RtclPro\Services\Mcp\Services;

defined( 'ABSPATH' ) || exit;

/**
 * "Mark as sold" support for the base MCP abilities.
 *
 * The sold flag (`_rtcl_mark_as_sold` post meta) is a Pro feature: Pro owns
 * the UI, the AJAX toggle and the frontend queries. Hooked into the base
 * search, update-listing-flags, get-listing and statistics abilities.
 */
class SoldService {

	public static function init() {
		add_filter( 'rtcl_mcp_search_meta_query', [ __CLASS__, 'search_meta_query' ], 10, 2 );
		add_filter( 'rtcl_mcp_listing_flags_input', [ __CLASS__, 'flags_input' ], 10, 2 );
		add_filter( 'rtcl_mcp_update_listing_flags', [ __CLASS__, 'update_flags' ], 10, 3 );
		add_filter( 'rtcl_mcp_listing_data', [ __CLASS__, 'listing_data' ], 10, 2 );
		add_filter( 'rtcl_mcp_listing_statistics', [ __CLASS__, 'statistics' ], 10, 4 );
		add_filter( 'rtcl_mcp_listing_schema_features', [ __CLASS__, 'schema_features' ] );
	}

	/**
	 * Sold filter for rtcl/search-listings.
	 *
	 * @param array $meta_query Meta query clauses.
	 * @param array $params     Search parameters.
	 *
	 * @return array
	 */
	public static function search_meta_query( $meta_query, $params ) {
		if ( isset( $params['sold'] ) ) {
			if ( $params['sold'] ) {
				$meta_query[] = [
					'key'     => '_rtcl_mark_as_sold',
					'value'   => '1',
					'compare' => '=',
				];
			} else {
				$meta_query[] = [
					'relation' => 'OR',
					[
						'key'     => '_rtcl_mark_as_sold',
						'compare' => 'NOT EXISTS',
					],
					[
						'key'     => '_rtcl_mark_as_sold',
						'value'   => '1',
						'compare' => '!=',
					],
				];
			}
		}

		return $meta_query;
	}

	/**
	 * Accept the `sold` flag in rtcl/update-listing-flags.
	 *
	 * @param array $flags Flags collected so far.
	 * @param array $input Ability input.
	 *
	 * @return array
	 */
	public static function flags_input( $flags, $input ) {
		if ( isset( $input['sold'] ) ) {
			$flags['sold'] = (bool) $input['sold'];
		}

		return $flags;
	}

	/**
	 * Apply the `sold` flag.
	 *
	 * @param array $changes    Applied changes.
	 * @param int   $listing_id Listing ID.
	 * @param array $flags      Requested flags.
	 *
	 * @return array
	 */
	public static function update_flags( $changes, $listing_id, $flags ) {
		if ( isset( $flags['sold'] ) ) {
			$old_sold = (bool) absint( get_post_meta( $listing_id, '_rtcl_mark_as_sold', true ) );
			$new_sold = (bool) $flags['sold'];
			if ( $new_sold ) {
				update_post_meta( $listing_id, '_rtcl_mark_as_sold', 1 );
			} else {
				delete_post_meta( $listing_id, '_rtcl_mark_as_sold' );
			}
			$changes['sold'] = [
				'old' => $old_sold,
				'new' => $new_sold,
			];
		}

		return $changes;
	}

	/**
	 * Sold state in the listing response.
	 *
	 * @param array                $data    Listing response data.
	 * @param \Rtcl\Models\Listing $listing Listing model.
	 *
	 * @return array
	 */
	public static function listing_data( $data, $listing ) {
		$data['sold'] = (bool) absint( get_post_meta( $listing->get_id(), '_rtcl_mark_as_sold', true ) );

		return $data;
	}

	/**
	 * Sold count in rtcl/get-listing-statistics, using the same filters as the base counts.
	 *
	 * @param array  $statistics Statistics.
	 * @param array  $filters    Requested filters.
	 * @param string $join       Prepared JOIN SQL (posts aliased `p`).
	 * @param string $where      Prepared WHERE SQL.
	 *
	 * @return array
	 */
	public static function statistics( $statistics, $filters, $join = '', $where = '' ) {
		global $wpdb;

		if ( '' === $where ) {
			$where = $wpdb->prepare( 'AND post_type = %s', rtcl()->post_type );
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$statistics['sold'] = (int) $wpdb->get_var(
			"SELECT COUNT(DISTINCT p.ID)
			 FROM {$wpdb->posts} AS p
			 INNER JOIN {$wpdb->postmeta} AS pm ON p.ID = pm.post_id AND pm.meta_key = '_rtcl_mark_as_sold' AND pm.meta_value = '1'
			 {$join}
			 WHERE 1=1 {$where}
			 AND post_status NOT IN ('auto-draft', 'trash', 'rtcl-temp')"
		);

		return $statistics;
	}

	/**
	 * List "Mark as Sold" in the listing schema features.
	 *
	 * @param array $info Feature availability info.
	 *
	 * @return array
	 */
	public static function schema_features( $info ) {
		$features = isset( $info['features'] ) && is_array( $info['features'] ) ? $info['features'] : [];
		array_unshift( $features, [
			'id'          => 'sold_status',
			'label'       => __( 'Mark as Sold', 'classified-listing-pro' ),
			'available'   => true,
			'description' => __( 'Mark listings as sold. Requires Classified Listing Pro.', 'classified-listing-pro' ),
		] );
		$info['features'] = $features;

		return $info;
	}
}
