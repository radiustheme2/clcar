<?php

namespace RtclPro\Controllers\Hooks;

use Rtcl\Helpers\Functions;
use RtclPro\Helpers\Fns;
use RtclPro\Helpers\PNHelper;
use RtclPro\Models\PushNotification;

class PushNotificationHooks {

	public static function init() {
		add_action( 'transition_post_status', [ __CLASS__, 'notify_device_for_listing_status_changes' ], 99, 3 );
		add_action( 'wp_insert_post', [ __CLASS__, 'notify_device_for_listing_order_created' ], 10, 3 );

		// Send News letter push notifications
		add_action( 'wp_ajax_rtcl_pro_send_news_letter_push_notification', [ __CLASS__, 'rtcl_pro_send_news_letter_push_notification' ] );
		add_action( 'wp_ajax_rtcl_pro_reset_news_letter_push_notification', [ __CLASS__, 'rtcl_pro_reset_news_letter_push_notification' ] );
		add_action( 'rtcl_pro_cron_send_newsletter_pn', [ __CLASS__, 'process_send_newsletter_pn' ] );
	}

	public static function rtcl_pro_send_news_letter_push_notification() {
		if ( !Fns::verify_pro_nonce() ) {
			wp_send_json_error( esc_html__( 'Session expired!!', 'classified-listing-pro' ) );
		}
		$title = esc_html( Functions::request( 'title' ) );
		$body = esc_html( Functions::request( 'body' ) );
		if ( !$title ) {
			wp_send_json_error( esc_html__( 'Title is required!', 'classified-listing-pro' ) );
		}
		if ( !$body ) {
			wp_send_json_error( esc_html__( 'Body is required!', 'classified-listing-pro' ) );
		}
		$title = mb_substr( $title, 0, 60 );
		$body = mb_substr( $body, 0, 230 );
		$data = [ 'title' => $title, 'body' => $body, 'offset' => 0 ];

		// Send the first batch inline so the admin gets immediate feedback
		// (managed hosts like WordPress.com run cron with several minutes' latency).
		$result = self::process_newsletter_batch( $data );

		if ( is_wp_error( $result ) ) {
			delete_option( 'rtcl_pro_cron_send_newsletter_pn_data' );
			wp_send_json_error( $result->get_error_message() );
		}

		$sent = absint( $result['data']['offset'] );

		if ( ! empty( $result['done'] ) ) {
			// Everything (or nothing) fit in the first batch — no cron needed.
			delete_option( 'rtcl_pro_cron_send_newsletter_pn_data' );
			$sent = min( $sent, self::count_push_tokens() );
			wp_send_json_success( sprintf(
			/* translators: %d: number of devices the notification was sent to */
				esc_html__( 'Notification sent to %d devices.', 'classified-listing-pro' ),
				$sent
			) );
		}

		// More batches remain — persist progress and let cron drain the rest.
		update_option( 'rtcl_pro_cron_send_newsletter_pn_data', $result['data'] );
		wp_schedule_single_event( time() + 5, 'rtcl_pro_cron_send_newsletter_pn' );

		$remaining = max( 0, self::count_push_tokens() - $sent );
		wp_send_json_success( sprintf(
		/* translators: 1: devices sent so far, 2: devices remaining */
			esc_html__( 'Sent to %1$d devices. %2$d remaining — sending in the background …', 'classified-listing-pro' ),
			$sent, $remaining
		) );
	}

	private static function count_push_tokens() {
		global $wpdb;
		$table = $wpdb->prefix . 'rtcl_push_notifications';

		return (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" );
	}

	public static function rtcl_pro_reset_news_letter_push_notification() {
		if ( !Fns::verify_pro_nonce() ) {
			wp_send_json_error( esc_html__( 'Session expired!!', 'classified-listing-pro' ) );
		}
		delete_option( 'rtcl_pro_cron_send_newsletter_pn_data' );
		wp_clear_scheduled_hook( 'rtcl_pro_cron_send_newsletter_pn' );

		wp_send_json_success( esc_html__( 'Newsletter queue cleared', 'classified-listing-pro' ) );
	}

	public static function process_send_newsletter_pn() {
		$data = get_option( 'rtcl_pro_cron_send_newsletter_pn_data', [] );
		if ( empty( $data ) || !is_array( $data ) ) {
			delete_option( 'rtcl_pro_cron_send_newsletter_pn_data' );
			return;
		}
		$result = self::process_newsletter_batch( $data );
		if ( is_wp_error( $result ) || ! empty( $result['done'] ) ) {
			delete_option( 'rtcl_pro_cron_send_newsletter_pn_data' );
			return;
		}
		// Schedule next batch
		update_option( 'rtcl_pro_cron_send_newsletter_pn_data', $result['data'] );
		wp_schedule_single_event( time() + 5, 'rtcl_pro_cron_send_newsletter_pn' );
	}

	/**
	 * Sends one batch (up to 99 tokens) of the newsletter push notification.
	 *
	 * @param array $data { title, body, offset }
	 *
	 * @return array|\WP_Error array{ done: bool, data: array } on success, WP_Error on failure.
	 */
	private static function process_newsletter_batch( array $data ) {
		$offset = absint( $data['offset'] );
		$limit = 99;
		global $wpdb;
		$pn = new PushNotification();
		$table = $wpdb->prefix . $pn->get_table_name();
		$pushTokens = $wpdb->get_col(
			$wpdb->prepare( "SELECT push_token FROM {$table} LIMIT %d OFFSET %d", $limit, $offset )
		);
		if ( empty( $pushTokens ) ) {
			return [ 'done' => true, 'data' => $data ];
		}
		$pn->setPushTokens( $pushTokens );
		try {
			$pn->notify_news_letter( $data );
		} catch ( \Throwable $e ) {
			error_log( 'RTCL newsletter PN aborted: ' . $e->getMessage() );
			return new \WP_Error( 'rtcl_pn_failed', esc_html__( 'Failed to send notification. Please try again.', 'classified-listing-pro' ) );
		}
		$data['offset'] = $offset + $limit;
		// Fewer than a full page returned -> this was the last batch.
		$done = count( $pushTokens ) < $limit;

		return [ 'done' => $done, 'data' => $data ];
	}

	public static function notify_device_for_listing_status_changes( $new_status, $old_status, $post ) {
		if ( rtcl()->post_type !== $post->post_type ) {
			return;
		}
		$listing = rtcl()->factory->get_listing( $post );
		$pn = new PushNotification();

		if ( 'publish' == $new_status ) {
			$pn->notify_user( PNHelper::EVENT_LISTING_APPROVED, [
				'user_id' => $listing->get_author_id(),
				'object'  => $listing
			] );
			return;
		}
		if ( 'rtcl-expired' == $new_status ) {
			$pn->notify_user( PNHelper::EVENT_LISTING_EXPIRED, [
				'user_id' => $listing->get_author_id(),
				'object'  => $listing
			] );
		}
	}

	public static function notify_device_for_listing_order_created( $post_id, $post, $update ) {
		if ( $update || rtcl()->post_type_pricing !== $post->post_type || rtcl()->post_type !== $post->post_type ) {
			return;
		}
		$pn = new PushNotification();
		if ( rtcl()->post_type !== $post->post_type ) {
			$listing = rtcl()->factory->get_listing( $post );
			$pn->notify_admin( PNHelper::EVENT_LISTING_CREATED, [
				'object' => $listing
			] );
		}
		if ( rtcl()->post_type_payment !== $post->post_type ) {
			$order = rtcl()->factory->get_order( $post );
			$pn->notify_admin( PNHelper::EVENT_ORDER_CREATED, [
				'object' => $order
			] );
		}
	}
}
