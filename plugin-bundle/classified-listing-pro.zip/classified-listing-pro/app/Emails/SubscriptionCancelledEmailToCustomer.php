<?php

namespace RtclPro\Emails;

use Rtcl\Helpers\Functions;
use Rtcl\Models\RtclEmail;
use RtclPro\Models\Subscription;
use WP_User;

class SubscriptionCancelledEmailToCustomer extends RtclEmail {

	public function __construct() {
		$this->id            = 'subscription_cancelled';
		$this->template_html = 'emails/subscription-cancelled-email-to-customer';

		parent::__construct();
	}

	public function get_default_subject() {
		return esc_html__( '[{site_title}] Your subscription has been cancelled', 'classified-listing-pro' );
	}

	public function get_default_heading() {
		return esc_html__( 'Subscription Cancelled', 'classified-listing-pro' );
	}

	/**
	 * @param Subscription $subscription
	 * @param mixed        $object Unused; kept for signature compatibility with RtclEmail::trigger().
	 */
	public function trigger( $subscription, $object = null ) {
		if ( ! $subscription instanceof Subscription ) {
			return;
		}

		$user = get_user_by( 'id', $subscription->getUserId() );
		if ( ! $user instanceof WP_User ) {
			return;
		}

		$this->setup_locale();
		$this->object = $subscription;
		$this->set_recipient( $user->user_email );

		if ( $this->get_recipient() ) {
			$this->send();
		}

		$this->restore_locale();
	}

	public function get_content_html() {
		return Functions::get_template_html(
			$this->template_html,
			[
				'subscription' => $this->object,
				'email'        => $this,
				'user'         => get_user_by( 'id', $this->object->getUserId() ),
			],
			'',
			rtclPro()->get_plugin_template_path()
		);
	}
}
