<?php

namespace RtclPro\Gateways\Stripe\lib;

use Rtcl\Helpers\Functions;
use Rtcl\Log\Logger;
use Rtcl\Models\Payment;
use Rtcl\Models\PaymentGateway;
use RtclPro\Gateways\Stripe\GatewayStripe;
use RtclPro\Models\Subscription;
use RtclPro\Models\Subscriptions;

class StripeHelper {

	/**
	 * @param Payment $order
	 *
	 * @return void
	 * @throws StripeException
	 */
	public static function createSubscription( Payment $order ) {
		$log = new Logger();

		$log->info( sprintf(
			'createSubscription: order=%d customer=%d pricing=%d total=%s %s',
			$order->get_id(),
			$order->get_customer_id(),
			$order->get_pricing_id(),
			$order->get_total(),
			$order->get_currency()
		) );
		$stripe = new StripeAPI();
		$price_id = get_post_meta( $order->get_pricing_id(), '_stripe_price_id', true );

		// A stored value that is not a Stripe price/plan ID is worse than no value at all: a plain
		// `empty()` check passes it straight through to Stripe, which rejects it — and because this
		// runs *after* payment_complete(), the customer ends up charged with no subscription and the
		// order flipped to failed. Treat anything malformed as missing so the product is recreated
		// and sites carrying junk in this meta key heal themselves on the next purchase.
		if ( ! self::is_valid_price_id( $price_id ) ) {
			if ( ! empty( $price_id ) ) {
				$log->warning( sprintf(
					'Discarding invalid _stripe_price_id "%s" on pricing %d — recreating the Stripe product/price.',
					is_scalar( $price_id ) ? $price_id : gettype( $price_id ),
					$order->get_pricing_id()
				) );
			}
			$product  = $stripe->createProduct( $order );
			$price_id = ! empty( $product->default_price ) ? $product->default_price : '';
		}

		// Guard: never send a subscription request with an empty price — Stripe rejects it and, with
		// the error now surfaced, the order would be marked failed after already being charged. Bail
		// loudly so the cause (missing recurring price / product setup) is visible in logs + notes.
		if ( empty( $price_id ) ) {
			$message = __( 'Stripe subscription not created: missing recurring price for this pricing plan. Verify the plan duration/visibility (billing interval) and Stripe product setup.', 'classified-listing-pro' );
			$log->error( $message . ' pricing_id=' . $order->get_pricing_id() );
			$order->add_note( $message );
			throw new StripeException( $message, $message );
		}

		$sSubscription = null;
		$subscriptionIn = ( new Subscriptions() )->findOneByUserId( $order->get_customer_id(), GatewayStripe::ID );
		if ( $subscriptionIn ) {
			$sSubscription = $stripe->retrieve( 'subscriptions/' . $subscriptionIn->getSubId() );
		}
		$stripeCustomer = new StripeCustomer( wp_get_current_user()->ID );
		$customer_id = $stripeCustomer->get_id();
		if ( !$customer_id ) {
			$customer_id = $stripeCustomer->create_customer();
		}
		$customer = $stripe->retrieve( 'customers/' . $customer_id );
		if ( !empty( $customer->sources->data[0] ) ) {
			$source = $customer->sources->data[0];
		} else {
			if ( !empty( $customer->invoice_settings->default_payment_method ) ) {
				$pm_object = $stripe->retrieve( 'payment_methods/' . $customer->invoice_settings->default_payment_method );
				if ( !empty( $pm_object->error ) ) {
					throw new StripeException( print_r( $pm_object, true ), $pm_object->error->message );
				}
				$source = (object)[
					'object'    => $pm_object->type,
					'last4'     => $pm_object->type === 'card' ? $pm_object->card->last4 : null,
					'exp_month' => $pm_object->type === 'card' ? $pm_object->card->exp_month : null,
					'exp_year'  => $pm_object->type === 'card' ? $pm_object->card->exp_year : null,
				];
			}

		}
		$enable_trial = get_post_meta( $order->get_pricing_id(), '_rtcl_enable_trial', true );
		$trial_days   = ( $enable_trial === '1' ) ? absint( get_post_meta( $order->get_pricing_id(), '_rtcl_trial_days', true ) ) : 0;

		if ( $sSubscription && !empty( $sSubscription->items->data[0] ) ) {
			if ( $sSubscription->items->data[0]->price->id !== $price_id ) {
				// Update subscription
				$update_args = [
					'items'    => [
						[
							'id'    => $sSubscription->items->data[0]->id,
							'price' => $price_id
						]
					],
					'metadata' => [
						'plane_id' => $order->get_pricing_id()
					],
				];
				if ( $trial_days > 0 ) {
					$update_args['trial_end'] = time() + ( $trial_days * 24 * 60 * 60 );
				}
				$sSubscription = $stripe->request( $update_args, 'subscriptions/' . $sSubscription->id );
				$subscriptionIn->update( [
					'name'       => $order->pricing->getTitle(),
					'product_id' => $order->pricing->getId(),
					'occurrence' => 1,
					'price'      => $order->get_total()
				] );
			} else {
				if ( $subscriptionIn->getProductId() !== $order->pricing->getId() ) {
					$subscriptionIn->update( [
						'name'       => $order->pricing->getTitle(),
						'product_id' => $order->pricing->getId(),
						'occurrence' => 1,
						'price'      => $order->get_total()
					] );
				}
			}


		} else {
			// Create subscription
			$new_sub_args = [
				'customer' => $customer_id,
				'items'    => [ [ 'price' => $price_id ] ],
				'currency' => strtolower( $order->get_currency() ),
				'metadata' => [
					'plane_id' => $order->get_pricing_id(),
					'order_id' => $order->get_id(),
				],
			];

			// Set the default payment method so Stripe can charge the first invoice.
			if ( ! empty( $customer->invoice_settings->default_payment_method ) ) {
				$new_sub_args['default_payment_method'] = $customer->invoice_settings->default_payment_method;
			}

			// Check if the order was already charged via a PaymentIntent (old flow / deferred
			// payment). When a transaction_id exists the customer has already paid — the
			// subscription must defer its first invoice to avoid a double charge.
			$already_charged = ! empty( $order->get_transaction_id() );

			if ( $trial_days > 0 ) {
				$new_sub_args['trial_period_days'] = $trial_days;
			} elseif ( $already_charged ) {
				// Old/existing flow: first period was paid via PaymentIntent.
				// Defer the subscription's first invoice to the next billing cycle.
				$period_days = absint( $order->pricing->getVisible() );
				if ( $period_days > 0 ) {
					$new_sub_args['billing_cycle_anchor'] = time() + ( $period_days * DAY_IN_SECONDS );
					$new_sub_args['prorate']              = 'false';
				}
			} else {
				// New flow: no PaymentIntent — let Stripe charge via the subscription's
				// first invoice. error_if_incomplete surfaces card declines immediately
				// instead of leaving the subscription in 'incomplete' status.
				$new_sub_args['payment_behavior'] = 'error_if_incomplete';
			}

			$sSubscription = $stripe->request( $new_sub_args, 'subscriptions' );

			$subscriptionIn = ( new Subscriptions() )->create( [
				'sub_id'     => $sSubscription->id,
				'gateway_id' => GatewayStripe::ID,
				'status'     => Subscription::STATUS_ACTIVE,
				'product_id' => $order->pricing->getId(),
				'occurrence' => 1,
				'price'      => $order->get_total(),
				'name'       => $order->pricing->getTitle(),
				'user_id'    => $order->get_customer_id()
			] );

			// New flow (not already charged): complete the order synchronously using
			// the charge from the subscription's first invoice. This avoids relying
			// on the charge.succeeded webhook which can race with this request.
			if ( ! $already_charged && $trial_days <= 0 && ! empty( $sSubscription->latest_invoice ) ) {
				try {
					$invoiceId = is_string( $sSubscription->latest_invoice )
						? $sSubscription->latest_invoice
						: $sSubscription->latest_invoice->id;
					$latestInvoice = $stripe->retrieve( 'invoices/' . $invoiceId );
					if ( ! empty( $latestInvoice->charge ) ) {
						$charge_id = is_string( $latestInvoice->charge )
							? $latestInvoice->charge
							: $latestInvoice->charge->id;
						$order->payment_complete( $charge_id );
						$order->add_note( sprintf(
							__( 'Stripe subscription first invoice paid (Charge ID: %s)', 'classified-listing-pro' ),
							$charge_id
						) );

						if ( ! empty( $latestInvoice->payment_intent ) ) {
							$intent_id = is_string( $latestInvoice->payment_intent )
								? $latestInvoice->payment_intent
								: $latestInvoice->payment_intent->id;
							update_post_meta( $order->get_id(), '_stripe_intent_id', $intent_id );
						}
					}
				} catch ( \Exception $e ) {
					$log->warning( sprintf(
						'createSubscription: could not complete order %d from invoice: %s',
						$order->get_id(),
						$e->getMessage()
					) );
				}
			}
		}
		if ( !is_wp_error( $subscriptionIn ) && !empty( $source ) && is_a( $subscriptionIn, Subscription::class ) ) {
			$ccData = [
				'type'   => $source->object,
				'last4'  => $source->last4,
				'expiry' => $source->exp_month . '/' . $source->exp_year
			];
			$subscriptionIn->update_meta( 'cc', $ccData );
		}
	}

	/**
	 * Is this a usable Stripe price identifier?
	 *
	 * Stripe price IDs are prefixed `price_`. Legacy `plan_` IDs from the older Plans API are still
	 * accepted by the `price` parameter and exist on long-running installs, so they pass too — this
	 * check only rejects values that Stripe could never resolve (a bare number, a title, an empty
	 * string). Deliberately format-only: verifying existence would cost an extra API round-trip on
	 * every subscription creation, and a well-formed but deleted ID surfaces a clear Stripe error.
	 *
	 * @param mixed $price_id Value stored in the `_stripe_price_id` meta.
	 *
	 * @return bool
	 */
	public static function is_valid_price_id( $price_id ) {
		return is_string( $price_id )
			   && ( str_starts_with( $price_id, 'price_' ) || str_starts_with( $price_id, 'plan_' ) );
	}

	/**
	 * Resolve the charge belonging to a PaymentIntent, across Stripe API versions.
	 *
	 * Stripe **removed** the `charges` list from PaymentIntent in API version `2022-11-15` and
	 * replaced it with `latest_charge`, which is a bare charge ID unless the caller expanded it.
	 * Reading `$intent->charges->data` directly therefore breaks on newer versions — and it breaks
	 * *after* the customer has been charged, leaving money taken and the order not completed.
	 *
	 * This matters even while `StripeAPI` stays pinned to `2019-09-09`, because webhook payloads are
	 * rendered using the API version configured on the **Dashboard endpoint**, not the version this
	 * plugin requests with. A site whose endpoint is on a recent version already receives intents
	 * without `charges`.
	 *
	 * @param object|null $intent A Stripe PaymentIntent.
	 *
	 * @return object|null The charge object, or null when the intent has no charge yet (a 3DS
	 *                     intent awaiting action is the normal case) or it could not be fetched.
	 */
	public static function get_charge_from_intent( $intent ) {
		if ( empty( $intent ) ) {
			return null;
		}

		// API <= 2022-11-14: charges is an expanded list on the intent.
		if ( ! empty( $intent->charges->data ) && is_array( $intent->charges->data ) ) {
			return end( $intent->charges->data );
		}

		// API >= 2022-11-15: latest_charge, expanded object or bare ID.
		if ( ! empty( $intent->latest_charge ) ) {
			if ( is_object( $intent->latest_charge ) ) {
				return $intent->latest_charge;
			}

			try {
				return ( new StripeAPI() )->retrieve( 'charges/' . $intent->latest_charge );
			} catch ( StripeException $e ) {
				StripeLogger::log( sprintf(
					'Could not retrieve charge %s for intent %s: %s',
					$intent->latest_charge,
					$intent->id ?? '?',
					$e->getMessage()
				) );

				return null;
			}
		}

		return null;
	}

	/**
	 * Map a Stripe **Subscription** status onto a local `Subscription::STATUS_*` value.
	 *
	 * Stripe's vocabulary is larger than ours and the two only overlap on three values, so the raw
	 * status used to be passed straight into `updateStatus()` — anything unmapped was rejected by the
	 * whitelist and the resulting WP_Error was discarded, leaving the local row stale (a `past_due`
	 * subscription silently stayed `active`).
	 *
	 * Local status is display/notification only — membership access is governed by the Store add-on's
	 * `wp_rtcl_membership` row, not by this value. Keep it that way: none of these mappings should be
	 * given access-control meaning without revisiting every consumer.
	 *
	 * @param string $stripeStatus Raw `status` from a Stripe Subscription object.
	 *
	 * @return string|null Local status, or null when there is no meaningful local equivalent
	 *                     (caller should leave the row untouched).
	 */
	public static function map_subscription_status( string $stripeStatus ): ?string {
		switch ( $stripeStatus ) {
			case 'active':
				return Subscription::STATUS_ACTIVE;
			case 'trialing':
				return Subscription::STATUS_TRIALING;
			case 'canceled':
				return Subscription::STATUS_CANCELED;
			// Renewal payment failed and Stripe is still retrying (smart retries run for days).
			// Not terminal — the customer may yet pay — so this is `failed`, not `suspended`.
			case 'past_due':
			// The very first invoice was not paid within Stripe's 23-hour window.
			case 'incomplete':
				return Subscription::STATUS_FAILED;
			// Stripe exhausted every retry and gave up, or collection was paused. The subscription
			// still exists but is not being collected on.
			case 'unpaid':
			case 'paused':
				return Subscription::STATUS_SUSPENDED;
			// The initial invoice was never paid and Stripe closed it out — terminal.
			case 'incomplete_expired':
				return Subscription::STATUS_TERMINATED;
			default:
				return null;
		}
	}

	/**
	 * Map a Stripe **SubscriptionSchedule** status onto a local `Subscription::STATUS_*` value.
	 *
	 * A schedule is a different object with a different enum (`not_started`, `active`, `completed`,
	 * `released`, `canceled`) — do not feed it through `map_subscription_status()`.
	 *
	 * `not_started` and `released` intentionally return null: nothing has happened yet in the first
	 * case, and in the second the schedule detached while the underlying subscription carries on, so
	 * the local status should be left to the `customer.subscription.*` events.
	 *
	 * @param string $scheduleStatus Raw `status` from a Stripe SubscriptionSchedule object.
	 *
	 * @return string|null Local status, or null to leave the row untouched.
	 */
	public static function map_schedule_status( string $scheduleStatus ): ?string {
		switch ( $scheduleStatus ) {
			case 'active':
				return Subscription::STATUS_ACTIVE;
			case 'completed':
				return Subscription::STATUS_EXPIRED;
			case 'canceled':
				return Subscription::STATUS_CANCELED;
			case 'not_started':
			case 'released':
			default:
				return null;
		}
	}

	/**
	 * Apply a mapped status to a local subscription, logging anything that goes wrong.
	 *
	 * `updateStatus()` returns a WP_Error for an unknown status or a no-op change; both call sites
	 * used to discard it silently. Centralised here so failures are visible in the Stripe log.
	 *
	 * @param Subscription $subscriptionIn Local subscription row.
	 * @param string|null  $localStatus    Mapped status, or null when unmapped.
	 * @param string       $rawStatus      Original Stripe status, for logging.
	 * @param string       $context        Event name, for logging.
	 *
	 * @return void
	 */
	public static function apply_mapped_status( Subscription $subscriptionIn, ?string $localStatus, string $rawStatus, string $context ) {
		if ( null === $localStatus ) {
			StripeLogger::log( sprintf(
				'%s: Stripe status "%s" has no local equivalent — subscription %s left as "%s".',
				$context,
				$rawStatus,
				$subscriptionIn->getSubId(),
				$subscriptionIn->getStatus()
			) );

			return;
		}

		if ( $localStatus === $subscriptionIn->getStatus() ) {
			return;
		}

		$updated = $subscriptionIn->updateStatus( $localStatus );
		if ( is_wp_error( $updated ) ) {
			StripeLogger::log( sprintf(
				'%s: failed to update subscription %s from "%s" to "%s" (Stripe status "%s"): %s',
				$context,
				$subscriptionIn->getSubId(),
				$subscriptionIn->getStatus(),
				$localStatus,
				$rawStatus,
				$updated->get_error_message()
			) );
		}
	}

	/**
	 * Gets the order by Stripe source ID.
	 *
	 * @param string $source_id
	 *
	 * @version 4.0.0
	 * @since   4.0.0
	 */
	public static function get_order_by_source_id( $source_id ) {
		global $wpdb;

		$order_id = $wpdb->get_var( $wpdb->prepare( "SELECT DISTINCT ID FROM $wpdb->posts as posts LEFT JOIN $wpdb->postmeta as meta ON posts.ID = meta.post_id WHERE meta.meta_value = %s AND meta.meta_key = %s", $source_id, '_stripe_source_id' ) );

		if ( !empty( $order_id ) ) {
			return rtcl()->fatory->get( $order_id );
		}

		return false;
	}


	/**
	 * Gets the order by Stripe charge ID.
	 *
	 * @param string $charge_id
	 *
	 * @since 4.1.16 Return false if charge_id is empty.
	 * @since 4.0.0
	 */
	public static function get_order_by_charge_id( $charge_id ) {
		global $wpdb;

		if ( empty( $charge_id ) ) {
			return false;
		}

		$order_id = $wpdb->get_var( $wpdb->prepare( "SELECT DISTINCT ID FROM $wpdb->posts as posts LEFT JOIN $wpdb->postmeta as meta ON posts.ID = meta.post_id WHERE meta.meta_value = %s AND meta.meta_key = %s", $charge_id, 'transaction_id' ) );

		if ( !empty( $order_id ) ) {
			return rtcl()->factory->get_order( $order_id );
		}

		return false;
	}

	/**
	 * Gets the order by Stripe PaymentIntent ID.
	 *
	 * @param string $intent_id The ID of the intent.
	 *
	 * @return Payment|bool Either an order or false when not found.
	 * @since 4.2
	 */
	public static function get_order_by_intent_id( $intent_id ) {
		global $wpdb;

		$order_id = $wpdb->get_var( $wpdb->prepare( "SELECT DISTINCT ID FROM $wpdb->posts as posts LEFT JOIN $wpdb->postmeta as meta ON posts.ID = meta.post_id WHERE meta.meta_value = %s AND meta.meta_key = %s", $intent_id, '_stripe_intent_id' ) );

		if ( !empty( $order_id ) ) {
			return rtcl()->factory->get_order( $order_id );
		}

		return false;
	}

	/**
	 * Gets the order by Stripe SetupIntent ID.
	 *
	 * @param string $intent_id The ID of the intent.
	 *
	 * @return Payment|bool Either an order or false when not found.
	 * @since 4.3
	 */
	public static function get_order_by_setup_intent_id( $intent_id ) {
		global $wpdb;

		$order_id = $wpdb->get_var( $wpdb->prepare( "SELECT DISTINCT ID FROM $wpdb->posts as posts LEFT JOIN $wpdb->postmeta as meta ON posts.ID = meta.post_id WHERE meta.meta_value = %s AND meta.meta_key = %s", $intent_id, '_stripe_setup_intent' ) );

		if ( !empty( $order_id ) ) {
			return rtcl()->factory->get_order( $order_id );
		}

		return false;
	}

	/**
	 * Checks Stripe minimum order value authorized per currency
	 */
	public static function get_minimum_amount() {
		// Check order amount
		switch ( Functions::get_order_currency() ) {
			case 'USD':
			case 'CAD':
			case 'EUR':
			case 'CHF':
			case 'AUD':
			case 'SGD':
				$minimum_amount = 50;
				break;
			case 'GBP':
				$minimum_amount = 30;
				break;
			case 'DKK':
				$minimum_amount = 250;
				break;
			case 'NOK':
			case 'SEK':
				$minimum_amount = 300;
				break;
			case 'JPY':
				$minimum_amount = 5000;
				break;
			case 'MXN':
				$minimum_amount = 1000;
				break;
			case 'HKD':
				$minimum_amount = 400;
				break;
			default:
				$minimum_amount = 50;
				break;
		}

		return $minimum_amount;
	}


	/**
	 * Get Stripe amount to pay
	 *
	 * @param float $total Amount due.
	 * @param string $currency Accepted currency.
	 *
	 * @return float|int
	 */
	public static function get_stripe_amount( $total, $currency = '' ) {
		if ( !$currency ) {
			$currency = Functions::get_order_currency();
		}

		if ( in_array( strtolower( $currency ), self::no_decimal_currencies() ) ) {
			return absint( $total );
		} else {
			return absint( Functions::format_decimal( ( (float)$total * 100 ), Functions::get_price_decimals() ) ); // In cents.
		}
	}

	public static function convertStripeAmoutToNormal( $total, $currency ) {
		if ( in_array( strtolower( $currency ), self::no_decimal_currencies() ) ) {
			return absint( $total );
		}

		$decimal = 2;
		$divider = 100;
		if ( in_array( strtolower( $currency ), self::threeDecimalCurrencies() ) ) {
			$decimal = 3;
			$divider = 1000;
		}
		return number_format( $total / $divider, $decimal, '.', '' );
	}

	public static function threeDecimalCurrencies() {
		return [
			'bhd',
			'jod',
			'kwd',
			'omr',
			'tnd'
		];
	}

	/**
	 * List of currencies supported by Stripe that has no decimals
	 * https://stripe.com/docs/currencies#zero-decimal from https://stripe.com/docs/currencies#presentment-currencies
	 *
	 * @return array $currencies
	 */
	public static function no_decimal_currencies() {
		return [
			'bif', // Burundian Franc
			'clp', // Chilean Peso
			'djf', // Djiboutian Franc
			'gnf', // Guinean Franc
			'jpy', // Japanese Yen
			'kmf', // Comorian Franc
			'krw', // South Korean Won
			'mga', // Malagasy Ariary
			'pyg', // Paraguayan Guaraní
			'rwf', // Rwandan Franc
			'ugx', // Ugandan Shilling
			'vnd', // Vietnamese Đồng
			'vuv', // Vanuatu Vatu
			'xaf', // Central African Cfa Franc
			'xof', // West African Cfa Franc
			'xpf', // Cfp Franc
		];
	}


	/**
	 * Stripe uses the smallest denomination in currencies such as cents.
	 * We need to format the returned currency from Stripe into human-readable form.
	 * The amount is not used in any calculations so returning string is sufficient.
	 *
	 * @param object $balance_transaction
	 * @param string $type Type of number to format
	 *
	 * @return string|void
	 */
	public static function format_balance_fee( $balance_transaction, $type = 'fee' ) {
		if ( !is_object( $balance_transaction ) ) {
			return;
		}

		if ( in_array( strtolower( $balance_transaction->currency ), self::no_decimal_currencies() ) ) {
			if ( 'fee' === $type ) {
				return $balance_transaction->fee;
			}

			return $balance_transaction->net;
		}

		if ( 'fee' === $type ) {
			return number_format( $balance_transaction->fee / 100, 2, '.', '' );
		}

		return number_format( $balance_transaction->net / 100, 2, '.', '' );
	}


	/**
	 * Gets the Stripe fee for order. With legacy check.
	 *
	 * @param Payment $order
	 *
	 * @return string $amount
	 * @since 4.1.0
	 */
	public static function get_stripe_fee( $order = null ) {
		if ( is_null( $order ) ) {
			return false;
		}

		return get_post_meta( $order->get_id(), '_stripe_fee', true );
	}

	/**
	 * Updates the Stripe fee for order.
	 *
	 * @param object $order
	 * @param float $amount
	 *
	 * @since 4.1.0
	 */
	public static function update_stripe_fee( $order = null, $amount = 0.0 ) {
		if ( is_null( $order ) ) {
			return false;
		}
		update_post_meta( $order->get_id(), '_stripe_fee', $amount );
	}

	/**
	 * Gets the Stripe fee for order. With legacy check.
	 *
	 * @param Payment $order
	 *
	 * @return string $amount
	 * @since 4.1.0
	 */
	public static function get_stripe_net( $order = null ) {
		if ( is_null( $order ) ) {
			return false;
		}

		return get_post_meta( $order->get_id(), '_stripe_net', true );
	}

	/**
	 * Updates the Stripe net for order.
	 *
	 * @param object $order
	 * @param float $amount
	 *
	 * @since 4.1.0
	 */
	public static function update_stripe_net( $order = null, $amount = 0.0 ) {
		if ( is_null( $order ) ) {
			return false;
		}
		update_post_meta( $order->get_id(), '_stripe_net', $amount );
	}

	/**
	 * Updates the Stripe currency for order.
	 *
	 * @param object $order
	 * @param string $currency
	 *
	 * @since 4.1.0
	 */
	public static function update_stripe_currency( $order, $currency ) {
		if ( is_null( $order ) ) {
			return false;
		}

		update_post_meta( $order->get_id(), '_stripe_currency', $currency );
	}


	/**
	 * Sanitize statement descriptor text.
	 *
	 * Stripe requires max of 22 characters and no special characters.
	 *
	 * @param string $statement_descriptor
	 *
	 * @return string $statement_descriptor Sanitized statement descriptor
	 * @since 4.0.0
	 */
	public static function clean_statement_descriptor( $statement_descriptor = '' ) {
		$disallowed_characters = [ '<', '>', '\\', '*', '"', "'", '/', '(', ')', '{', '}' ];

		// Strip any tags.
		$statement_descriptor = strip_tags( $statement_descriptor );

		// Strip any HTML entities.
		// Props https://stackoverflow.com/questions/657643/how-to-remove-html-special-chars .
		$statement_descriptor = preg_replace( '/&#?[a-z0-9]{2,8};/i', '', $statement_descriptor );

		// Next, remove any remaining disallowed characters.
		$statement_descriptor = str_replace( $disallowed_characters, '', $statement_descriptor );

		// Trim any whitespace at the ends and limit to 22 characters.
		$statement_descriptor = substr( trim( $statement_descriptor ), 0, 22 );

		return $statement_descriptor;
	}

	/**
	 * Converts a WooCommerce locale to the closest supported by Stripe.js.
	 *
	 * Stripe.js supports only a subset of IETF language tags, if a country specific locale is not supported we use
	 * the default for that language (https://stripe.com/docs/js/appendix/supported_locales).
	 * If no match is found we return 'auto' so Stripe.js uses the browser locale.
	 *
	 * @param string $rtcl_locale The locale to convert.
	 *
	 * @return string Closest locale supported by Stripe ('auto' if NONE).
	 */
	public static function convert_rtcl_locale_to_stripe_locale( $rtcl_locale ) {
		// List copied from: https://stripe.com/docs/js/appendix/supported_locales.
		$supported = [
			'ar',     // Arabic.
			'bg',     // Bulgarian (Bulgaria).
			'cs',     // Czech (Czech Republic).
			'da',     // Danish.
			'de',     // German (Germany).
			'el',     // Greek (Greece).
			'en',     // English.
			'en-GB',  // English (United Kingdom).
			'es',     // Spanish (Spain).
			'es-419', // Spanish (Latin America).
			'et',     // Estonian (Estonia).
			'fi',     // Finnish (Finland).
			'fr',     // French (France).
			'fr-CA',  // French (Canada).
			'he',     // Hebrew (Israel).
			'hu',     // Hungarian (Hungary).
			'id',     // Indonesian (Indonesia).
			'it',     // Italian (Italy).
			'ja',     // Japanese.
			'lt',     // Lithuanian (Lithuania).
			'lv',     // Latvian (Latvia).
			'ms',     // Malay (Malaysia).
			'mt',     // Maltese (Malta).
			'nb',     // Norwegian Bokmål.
			'nl',     // Dutch (Netherlands).
			'pl',     // Polish (Poland).
			'pt-BR',  // Portuguese (Brazil).
			'pt',     // Portuguese (Brazil).
			'ro',     // Romanian (Romania).
			'ru',     // Russian (Russia).
			'sk',     // Slovak (Slovakia).
			'sl',     // Slovenian (Slovenia).
			'sv',     // Swedish (Sweden).
			'th',     // Thai.
			'tr',     // Turkish (Turkey).
			'zh',     // Chinese Simplified (China).
			'zh-HK',  // Chinese Traditional (Hong Kong).
			'zh-TW',  // Chinese Traditional (Taiwan).
		];

		// Stripe uses '-' instead of '_' (used in WordPress).
		$locale = str_replace( '_', '-', $rtcl_locale );

		if ( in_array( $locale, $supported, true ) ) {
			return $locale;
		}

		// The plugin has been fully translated for Spanish (Ecuador), Spanish (Mexico), and
		// Spanish(Venezuela), and partially (88% at 2021-05-14) for Spanish (Colombia).
		// We need to map these locales to Stripe's Spanish (Latin America) 'es-419' locale.
		// This list should be updated if more localized versions of Latin American Spanish are
		// made available.
		$lowercase_locale = strtolower( $rtcl_locale );
		$translated_latin_american_locales = [
			'es_co', // Spanish (Colombia).
			'es_ec', // Spanish (Ecuador).
			'es_mx', // Spanish (Mexico).
			'es_ve', // Spanish (Venezuela).
		];
		if ( in_array( $lowercase_locale, $translated_latin_american_locales, true ) ) {
			return 'es-419';
		}

		// Finally, we check if the "base locale" is available.
		$base_locale = substr( $rtcl_locale, 0, 2 );
		if ( in_array( $base_locale, $supported, true ) ) {
			return $base_locale;
		}

		// Default to 'auto' so Stripe.js uses the browser locale.
		return 'auto';
	}

	/**
	 * Localize Stripe messages based on code
	 *
	 * @return array
	 * @version 3.0.6
	 * @since   3.0.6
	 */
	public static function get_localized_messages() {
		return apply_filters(
			'rtcl_stripe_localized_messages',
			[
				'invalid_number'           => __( 'The card number is not a valid credit card number.', 'classified-listing-pro' ),
				'invalid_expiry_month'     => __( 'The card\'s expiration month is invalid.', 'classified-listing-pro' ),
				'invalid_expiry_year'      => __( 'The card\'s expiration year is invalid.', 'classified-listing-pro' ),
				'invalid_cvc'              => __( 'The card\'s security code is invalid.', 'classified-listing-pro' ),
				'incorrect_number'         => __( 'The card number is incorrect.', 'classified-listing-pro' ),
				'incomplete_number'        => __( 'The card number is incomplete.', 'classified-listing-pro' ),
				'incomplete_cvc'           => __( 'The card\'s security code is incomplete.', 'classified-listing-pro' ),
				'incomplete_expiry'        => __( 'The card\'s expiration date is incomplete.', 'classified-listing-pro' ),
				'expired_card'             => __( 'The card has expired.', 'classified-listing-pro' ),
				'incorrect_cvc'            => __( 'The card\'s security code is incorrect.', 'classified-listing-pro' ),
				'incorrect_zip'            => __( 'The card\'s zip code failed validation.', 'classified-listing-pro' ),
				'invalid_expiry_year_past' => __( 'The card\'s expiration year is in the past', 'classified-listing-pro' ),
				'card_declined'            => __( 'The card was declined.', 'classified-listing-pro' ),
				'missing'                  => __( 'There is no card on a customer that is being charged.', 'classified-listing-pro' ),
				'processing_error'         => __( 'An error occurred while processing the card.', 'classified-listing-pro' ),
				'invalid_sofort_country'   => __( 'The billing country is not accepted by SOFORT. Please try another country.', 'classified-listing-pro' ),
				'email_invalid'            => __( 'Invalid email address, please correct and try again.', 'classified-listing-pro' ),
				'invalid_request_error'    => __( 'Unable to process this payment, please try again or use alternative method.', 'classified-listing-pro' )
			]
		);
	}

	static function get_invoice_id_from_idempotency_key( $event ) {
		$idempotency_key = $event->request->idempotency_key ?? '';

		if ( preg_match( '/^(in_[^-]+)/', $idempotency_key, $matches ) ) {
			return $matches[1];
		}

		return null;
	}
}
