<?php

namespace RtclPro\Gateways\Stripe\lib;

use Rtcl\Helpers\Functions;
use Rtcl\Models\Payment;
use stdClass;
use WP_Error;

class StripeAPI {

	/**
	 * Stripe API Endpoint
	 */
	const ENDPOINT = 'https://api.stripe.com/v1/';
	const STRIPE_API_VERSION = '2019-09-09';

	/**
	 * Secret API Key.
	 *
	 * @var string
	 */
	private static $secret_key = '';

	private string $secretKey;

	private StripeCustomer $customer;

	/**
	 * Set secret API Key.
	 *
	 * @param $secret_key
	 */
	public static function set_secret_key( $secret_key ) {
		self::$secret_key = $secret_key;
	}

	public function __construct() {
		$this->setSecretKey();
	}

	public function setSecretKey() {
		$options = Functions::get_option( 'rtcl_payment_stripe' );
		if ( isset( $options['testmode'], $options['stripe_livesecretkey'], $options['stripe_testsecretkey'] ) ) {
			$this->secretKey = 'yes' === $options['testmode'] ? $options['stripe_testsecretkey'] : $options['stripe_livesecretkey'];
		} elseif ( isset( $options['stripe_sandbox'], $options['stripe_livesecretkey'], $options['stripe_testsecretkey'] ) ) {
			$this->secretKey = 'yes' === $options['stripe_sandbox'] ? $options['stripe_testsecretkey'] : $options['stripe_livesecretkey'];
		}
	}

	/**
	 * Get secret key.
	 *
	 * @return string
	 */
	public static function get_secret_key() {
		if ( ! self::$secret_key ) {
			$options = Functions::get_option( 'rtcl_payment_stripe' );
			if ( isset( $options['testmode'], $options['stripe_livesecretkey'], $options['stripe_testsecretkey'] ) ) {
				self::set_secret_key( 'yes' === $options['testmode'] ? $options['stripe_testsecretkey'] : $options['stripe_livesecretkey'] );
			} elseif ( isset( $options['stripe_sandbox'], $options['stripe_livesecretkey'], $options['stripe_testsecretkey'] ) ) {
				self::set_secret_key( 'yes' === $options['stripe_sandbox'] ? $options['stripe_testsecretkey'] : $options['stripe_livesecretkey'] );
			}
		}

		return self::$secret_key;
	}

	/**
	 * Generates the user agent we use to pass to API request so
	 * Stripe can identify our application.
	 *
	 * @since   4.0.0
	 * @version 4.0.0
	 */
	public static function get_user_agent() {
		$app_info = [
			'name'       => 'Classified Listing Stripe Gateway',
			'version'    => RTCL_PRO_VERSION,
			'url'        => 'https://www.radiustheme.com/downloads/classified-listing-pro-wordpress/',
			'partner_id' => 'pp_partner_EYuSt9peR0WTMg',
		];

		return [
			'lang'         => 'php',
			'lang_version' => phpversion(),
			'publisher'    => 'rtcl',
			'uname'        => php_uname(),
			'application'  => $app_info,
		];
	}

	/**
	 * Generates the headers to pass to API request.
	 *
	 * @since   4.0.0
	 * @version 4.0.0
	 */
	public function get_headers() {
		$user_agent = $this->get_user_agent();
		$app_info   = $user_agent['application'];

		$headers = apply_filters(
			'rtcl_stripe_request_headers',
			[
				'Authorization'  => 'Basic ' . base64_encode( $this->secretKey . ':' ),
				'Stripe-Version' => self::STRIPE_API_VERSION,
			]
		);

		// These headers should not be overridden for this gateway.
		$headers['User-Agent']                 = $app_info['name'] . '/' . $app_info['version'] . ' (' . $app_info['url'] . ')';
		$headers['X-Stripe-Client-User-Agent'] = wp_json_encode( $user_agent );

		return $headers;
	}

	/**
	 * Send the request to Stripe's API
	 *
	 * @param array  $request
	 * @param string $api
	 * @param string $method
	 * @param bool   $with_headers   To get the response with headers.
	 * @param bool   $throw_on_error Whether an API-level error should throw (default) or be returned
	 *                               to the caller as the decoded `->error` object. Only pass false
	 *                               when the caller inspects the error and can recover from it — see
	 *                               `request_with_level3_data()`. Errors are logged either way.
	 *
	 * @return stdClass|array
	 * @throws StripeException
	 * @since   3.1.0
	 * @version 4.0.6
	 */
	public function request( $request, $api = 'charges', $method = 'POST', $with_headers = false, $throw_on_error = true ) {
		StripeLogger::log( "{$api} request: " . print_r( $request, true ) );

		$headers         = $this->get_headers();
		$idempotency_key = '';

		if ( 'charges' === $api && 'POST' === $method ) {
			$customer        = ! empty( $request['customer'] ) ? $request['customer'] : '';
			$source          = ! empty( $request['source'] ) ? $request['source'] : $customer;
			$idempotency_key = apply_filters( 'rtcl_stripe_idempotency_key', $request['metadata']['order_id'] . '-' . $source, $request );

			$headers['Idempotency-Key'] = $idempotency_key;
		}

		$response = wp_safe_remote_post(
			self::ENDPOINT . $api,
			[
				'method'  => $method,
				'headers' => $headers,
				'body'    => apply_filters( 'rtcl_stripe_request_body', $request, $api ),
				'timeout' => 70,
			]
		);

		if ( is_wp_error( $response ) || empty( $response['body'] ) ) {
			StripeLogger::log(
				'Error Response: ' . print_r( $response, true ) . PHP_EOL . PHP_EOL . 'Failed request: ' . print_r(
					[
						'api'             => $api,
						'request'         => $request,
						'idempotency_key' => $idempotency_key,
					],
					true
				)
			);

			throw new StripeException( print_r( $response, true ), __( 'There was a problem connecting to the Stripe API endpoint.', 'classified-listing-pro' ) );
		}
		$responseData = json_decode( $response['body'] );

		// Surface Stripe API errors instead of silently returning the error object. (Previously an
		// early `return` above this check made it dead code, so failed subscription/charge requests
		// were swallowed — the order looked fine but no subscription was created.)
		if ( ! empty( $responseData->error ) ) {
			$err = $responseData->error;
			// Full technical error goes to the log for admins/support.
			StripeLogger::log( "Stripe API error ({$api}): " . print_r( $err, true ) );

			// Hand the error back instead of throwing when the caller has said it can recover from
			// it. Without this, a caller that inspects `$result->error` never runs — which is exactly
			// how the level3 retry in request_with_level3_data() silently became dead code.
			if ( ! $throw_on_error ) {
				return $responseData;
			}

			// First arg (getMessage) is what the UI displays; keep the raw detail only in the log above.
			$user_message = self::get_user_error_message( $err );
			throw new StripeException( $user_message, $user_message );
		}

		if ( $with_headers ) {
			return [
				'headers' => wp_remote_retrieve_headers( $response ),
				'body'    => $responseData,
			];
		}

		return $responseData;
	}

	/**
	 * Retrieve API endpoint.
	 *
	 * @param string $api
	 *
	 * @throws StripeException
	 * @since         4.0.0
	 * @version       4.0.0
	 */
	public function retrieve( string $api ) {
		StripeLogger::log( "{$api}" );

		$response = wp_safe_remote_get(
			self::ENDPOINT . $api,
			[
				'method'  => 'GET',
				'headers' => $this->get_headers(),
				'timeout' => 70,
			]
		);

		if ( is_wp_error( $response ) || empty( $response['body'] ) ) {
			StripeLogger::log( 'Error Response: ' . print_r( $response, true ) );

			throw new StripeException( __( 'There was a problem connecting to the Stripe API endpoint.', 'classified-listing-pro' ) );
		}

		$responseData = json_decode( $response['body'] );
		if ( ! empty( $responseData->error ) ) {
			throw new StripeException( $responseData->error->message );
		}

		return $responseData;
	}

	/**
	 * Build the customer-facing message for a Stripe API error.
	 *
	 * Card errors (declines, insufficient funds, expired card, wrong CVC) already carry a clear,
	 * customer-friendly message from Stripe — surface it as-is. Everything else
	 * (invalid_request_error, api_error, rate_limit …) is internal/config noise like
	 * "Invalid boolean: 0" or "Received unknown parameter: level3" that only confuses the buyer —
	 * show a clean generic message and keep the specifics in the log.
	 *
	 * @param object $err The `error` object from a Stripe response.
	 *
	 * @return string
	 */
	private static function get_user_error_message( $err ) {
		$is_card_error = ! empty( $err->type ) && 'card_error' === $err->type;

		return ( $is_card_error && ! empty( $err->message ) )
			? $err->message
			: __( 'We couldn\'t complete your payment right now. Please try again in a moment, or contact support if the problem continues.', 'classified-listing-pro' );
	}

	/**
	 * Send the request to Stripe's API with level 3 data generated
	 * from the order. If the request fails due to an error related
	 * to level3 data, make the request again without it to allow
	 * the payment to go through.
	 *
	 * @param array   $request     Array with request parameters.
	 * @param string  $api         The API path for the request.
	 * @param array   $level3_data The level 3 data for this request.
	 * @param Payment $order       The order associated with the payment.
	 *
	 * @return stdClass|array The response
	 * @throws StripeException
	 * @since   4.3.2
	 * @version 5.1.0
	 *
	 */
	public function request_with_level3_data( $request, $api, $level3_data, $order ) {
		// 1. Do not add level3 data if the array is empty.
		// 2. Do not add level3 data if there's a transient indicating that level3 was
		// not accepted by Stripe in the past for this account.
		// 3. Do not try to add level3 data if merchant is not based in the US.
		// https://stripe.com/docs/level3#level-iii-usage-requirements
		// (Needs to be authenticated with a level3 gated account to see above docs).
		if (
			empty( $level3_data ) ||
			get_transient( 'rtcl_stripe_level3_not_allowed' )
            ||'US' !== rtcl()->countries->get_base_country()
		) {
			return $this->request(
				$request,
				$api
			);
		}

		// Add level 3 data to the request.
		$request['level3'] = $level3_data;

		// Ask for the error object rather than an exception: a level3 rejection is recoverable and
		// is handled by the retry below. Anything we can't recover from is re-thrown at the end.
		$result = $this->request(
			$request,
			$api,
			'POST',
			false,
			false
		);

		$is_level3_param_not_allowed = (
			isset( $result->error )
			&& isset( $result->error->code )
			&& 'parameter_unknown' === $result->error->code
			&& isset( $result->error->param )
			&& 'level3' === $result->error->param
		);

		$is_level_3data_incorrect = (
			isset( $result->error )
			&& isset( $result->error->type )
			&& 'invalid_request_error' === $result->error->type
		);

		if ( $is_level3_param_not_allowed ) {
			// Set a transient so that future requests do not add level 3 data.
			// Transient is set to expire in 3 months, can be manually removed if needed.
			set_transient( 'rtcl_stripe_level3_not_allowed', true, 3 * MONTH_IN_SECONDS );
			StripeLogger::log( 'Level3 not supported by this Stripe account — retrying without it and suppressing for 3 months.' );
		} elseif ( $is_level_3data_incorrect ) {
			// Log the issue so we could debug it.
			StripeLogger::log(
				'Level3 data sum incorrect: ' . PHP_EOL
				. print_r( $result->error->message, true ) . PHP_EOL
			);
		}

		// Make the request again without level 3 data. This retry throws on failure (the default),
		// so a genuine problem still reaches the caller — only the level3 rejection is swallowed.
		// `$this->`, not `self::`: request() is an instance method.
		if ( $is_level3_param_not_allowed || $is_level_3data_incorrect ) {
			unset( $request['level3'] );

			return $this->request(
				$request,
				$api
			);
		}

		// Not a level3 problem, so there is nothing to recover from. We suppressed the throw when
		// making the request above, so re-raise it here to keep request()'s contract: an unhandled
		// API error must never be returned to a caller as a silent value.
		if ( isset( $result->error ) ) {
			$user_message = self::get_user_error_message( $result->error );
			throw new StripeException( $user_message, $user_message );
		}

		return $result;
	}

	/**
	 * @param Payment $order
	 *
	 * @return Object
	 * @throws StripeException
	 */
	public function createProduct( Payment $order ) {
		// The recurring interval_count is the plan's visible-days duration; Stripe requires >= 1.
		// A plan with visible = 0 ("never expires") has no billing period and can't be a recurring
		// subscription — fail early with a clear, actionable message instead of Stripe's generic
		// "must be greater than or equal to 1" error.
		$interval_count = absint( $order->pricing->getVisible() );
		if ( $interval_count < 1 ) {
			$message = __( 'This subscription plan cannot be purchased because its visibility duration (billing interval) is not set. Please set the plan\'s "Visible Days" to 1 or more.', 'classified-listing-pro' );
			StripeLogger::log( 'createProduct aborted: interval_count < 1 for pricing_id=' . $order->get_pricing_id() );
			throw new StripeException( $message, $message );
		}

		$response = $this->request( [
			'name'               => $order->pricing->getTitle(),
			'default_price_data' => [
				'unit_amount' => StripeHelper::get_stripe_amount( $order->get_total() ),
				'currency'    => strtolower( $order->get_currency() ),
				'recurring'   => [
					'interval'       => 'day',
					'interval_count' => $interval_count
				]
			]
		], 'products' );
		update_post_meta( $order->get_pricing_id(), '_stripe_product_id', $response->id );
		update_post_meta( $order->get_pricing_id(), '_stripe_price_id', $response->default_price );

		return $response;
	}

	/**
	 * @return StripeCustomer
	 */
	public function getCustomer(): StripeCustomer {
		if ( empty( $this->customer ) ) {
			$this->customer = new StripeCustomer( wp_get_current_user()->ID );
		}

		return $this->customer;
	}

	/**
	 * @param StripeCustomer|int $customer Stripe Customer or user id
	 */
	public function setCustomer( $customer ): void {
		if ( is_int( $customer ) ) {
			$this->customer = new StripeCustomer( $customer );
		} else if ( is_a( $customer, StripeCustomer::class ) ) {
			$this->customer = $customer;
		}
	}
}
