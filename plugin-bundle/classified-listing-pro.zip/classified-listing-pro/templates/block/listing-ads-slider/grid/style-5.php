<?php
/**
 * Listing Slider block — grid style 5.
 *
 * Price flag on the photo and a divided seller/action bar along the bottom.
 *
 * The Listing Showcase card from Classified Listing, as Swiper slides: the
 * same arrangement as the Listings block's grid style 5 and the Elementor
 * Listing Slider, styled by the base plugin's `_listing-showcase.scss`. The
 * card fragments come from `Rtcl\Helpers\ListingShowcase::parts()`.
 *
 * `ListingAdsSlider::render_callback_listings()` only picks this template when
 * that helper exists; with an older Classified Listing it renders
 * `legacy/style-5.php` instead.
 *
 * @author     RadiusTheme
 * @package    classified-listing-pro/templates
 * @version    2.0.0
 *
 * @var array  $instance
 * @var array  $the_loops
 * @var string $style
 * @var string $default_template_path
 */

use Rtcl\Helpers\Functions;
use Rtcl\Helpers\Icons;
use Rtcl\Helpers\ListingShowcase;

defined( 'ABSPATH' ) || exit;

$data = [
	'instance' => $instance,
	'style'    => $style,
	'showcase' => true,
];
Functions::get_template( 'block/listing-ads-slider/grid/slider-header', $data, '', $default_template_path );

if ( ! empty( $the_loops['posts'] ) ) {
	foreach ( $the_loops['posts'] as $the_loop ) {
		$parts = ListingShowcase::parts(
			$the_loop,
			$instance,
			[
				'description'   => 'grid_content',
				'thumb'         => 'plain',
				'thumb_badges'  => false,
				'thumb_actions' => false,
				'bottom'        => 'author',
				'icon'          => 'quick-view',
			]
		);

		// One `wp_kses()` over the assembled card: `wp_kses_post()` strips the
		// inline SVG icons, which need the allowlist `Icons` publishes.
		$card = sprintf(
			'%s<div class="item-content">%s %s %s %s %s %s %s</div>',
			ListingShowcase::thumb_with( $parts['thumb'], $parts['price'] ),
			$parts['labels'],
			$parts['category'],
			$parts['title'],
			$parts['custom_field'],
			$parts['meta'],
			$parts['description'],
			$parts['bottom']
		);

		// The card itself is the slide, as in the Elementor slider, so the
		// card design's own frame is what Swiper sizes and spaces.
		$classes = array_merge( (array) $the_loop['classes'], [ 'swiper-slide' ] );
		?>
		<div class="<?php echo esc_attr( implode( ' ', $classes ) ); ?>">
			<?php echo wp_kses( $card, Icons::allowed_html() ); ?>
		</div>
		<?php
	}
}

Functions::get_template( 'block/listing-ads-slider/grid/slider-footer', $data, '', $default_template_path );
