<?php
/**
 * Listing Category block — style 2.
 *
 * Renders the same markup as the Elementor Listing Category widget's style 2
 * (`classified-listing-toolkits/templates/elementor/listing-cat-box/grid-style-2.php`)
 * so both share one design, which lives in the base plugin at
 * `src/sass/partials/elementor/_elementor-widget-category.scss`.
 *
 * Every element also carries the block's own class (`rtcl-gb-cat-box`,
 * `item-content`, `title`, `counter`, `content`, `item-icon`, `rtcl-sub-cats`)
 * because those are the selectors the block's style attributes generate CSS
 * against — dropping them would discard the settings existing users have saved.
 * Keep in step with `src/blocks/listing-cat-box/layout/style-grid2.js` in the
 * base plugin, which draws the editor preview.
 *
 * @package Classified-listing-pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$col_class  = 'rtcl-grid-view';
$col_class .= ' columns-' . $settings['col_desktop'];
$col_class .= ' tab-columns-' . $settings['col_tablet'];
$col_class .= ' mobile-columns-' . $settings['col_mobile'];
$col_class .= ' rtcl-gb-cat-wrap';

$visibility = ! empty( $settings['content_visibility'] ) ? $settings['content_visibility'] : [];
$show_icon  = ! empty( $visibility['icon'] );

// The block stores alignment as `rtcl-text-<x>`; the shared stylesheet keys off
// `cat-box-<x>-alignment`. Empty stays empty.
$align_map     = [
	'rtcl-text-left'   => 'cat-box-left-alignment',
	'rtcl-text-right'  => 'cat-box-right-alignment',
	'rtcl-text-center' => '',
];
$content_align = ! empty( $visibility['contentAlign'] ) ? $visibility['contentAlign'] : '';
$align_class   = isset( $align_map[ $content_align ] ) ? $align_map[ $content_align ] : '';

$grid_classes = [
	'rtcl',
	'rtcl-gb-block',
	'rtcl-categories',
	'rtcl-categories-elementor',
	'rtcl-categories-grid',
	'rt-el-listing-cat-box-2',
	$show_icon ? 'has-cat-icon' : 'no-cat-icon',
];
if ( $align_class ) {
	$grid_classes[] = $align_class;
}

$item_class  = 'cat-details rtcl-gb-cat-box';
$item_class .= ' rtcl-gb-cat-box-' . $settings['col_style']['style'];
if ( $content_align ) {
	$item_class .= ' ' . $content_align;
}

$wrap_class = '';
if ( isset( $settings['blockId'] ) ) {
	$wrap_class .= 'rtcl-block-' . $settings['blockId'];
}
$wrap_class .= ' rtcl-block-frontend ';
if ( isset( $settings['className'] ) ) {
	$wrap_class .= $settings['className'];
}
// Empty means no alignment — `isset()` let an empty value through and
// produced a bare `align` class.
if ( ! empty( $settings['align'] ) ) {
	$wrap_class .= ' align' . $settings['align'] . ' ';
}

$icon_class = ( 'icon' === $settings['icon_type'] ) ? 'icon item-icon' : 'image icon item-image';
?>

<?php if ( ! empty( $terms ) ) { ?>
	<div class="<?php echo esc_attr( $wrap_class ); ?>">
		<div class="<?php echo esc_attr( implode( ' ', $grid_classes ) ); ?>">
			<div class="<?php echo esc_attr( $col_class ); ?>">
				<?php foreach ( $terms as $term ) { ?>
					<div class="cat-item-wrap listing-item">
						<div class="<?php echo esc_attr( $item_class ); ?>">
							<div class="cat-details-inner">
								<div class="rtin-head-area rtcl-box-head">
									<?php if ( $show_icon && ! empty( $term['icon_html'] ) ) : ?>
										<div class="<?php echo esc_attr( $icon_class ); ?>">
											<a href="<?php echo esc_url( $term['permalink'] ); ?>"><?php echo wp_kses_post( $term['icon_html'] ); ?></a>
										</div>
									<?php endif; ?>

									<div class="rtcl-title-wrapper item-content">
										<h3 class="rtcl-category-title title">
											<a href="<?php echo esc_url( $term['permalink'] ); ?>"><?php echo esc_html( $term['name'] ); ?></a>
										</h3>

										<?php
										if ( ! empty( $visibility['counter'] ) && isset( $term['count'] ) ) :
											$count = (int) $term['count'];
											?>
											<div class="views counter">
												<div class="view-inner">
													<span class="dot"></span>
													<?php if ( ! empty( $settings['count_after_text'] ) ) : ?>
														<?php echo esc_html( $count ); ?>
														<span class="ads-count"><?php echo esc_html( $settings['count_after_text'] ); ?></span>
													<?php else : ?>
														<span class="ads-count">
															<?php
															printf(
																/* translators: %s: number of ads in this category */
																esc_html( _n( '%s Ad', '%s Ads', $count, 'classified-listing-pro' ) ),
																esc_html( $count )
															);
															?>
														</span>
													<?php endif; ?>
												</div>
											</div>
										<?php endif; ?>
									</div>
								</div>

								<div class="box-body rtcl-box-body">
									<?php if ( ! empty( $visibility['subCat'] ) && ! empty( $term['child_html'] ) ) : ?>
										<ul class="rtin-sub-cats rtcl-sub-cats"><?php echo wp_kses_post( $term['child_html'] ); ?></ul>
									<?php endif; ?>

									<?php if ( ! empty( $visibility['catDesc'] ) && ! empty( $term['description'] ) ) : ?>
										<div class="description-section">
											<p class="content">
												<?php
												if ( $settings['content_limit'] ) {
													echo esc_html( wp_trim_words( $term['description'], $settings['content_limit'] ) );
												} else {
													echo wp_kses_post( $term['description'] );
												}
												?>
											</p>
										</div>
									<?php endif; ?>
								</div>
							</div>
						</div>
					</div>
				<?php } ?>
			</div>
		</div>
	</div>
<?php } ?>
